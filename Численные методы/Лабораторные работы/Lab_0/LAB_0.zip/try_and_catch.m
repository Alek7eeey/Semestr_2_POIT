try a = b
catch
    a = 0
end
