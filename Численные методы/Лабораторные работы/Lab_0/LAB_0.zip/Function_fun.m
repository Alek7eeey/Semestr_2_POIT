function Fun(x)
a=[2 3 4];
b=[1 2 3];
display(a,b)
end
function display(first,second)
c = first+second;
disp(c)
end
