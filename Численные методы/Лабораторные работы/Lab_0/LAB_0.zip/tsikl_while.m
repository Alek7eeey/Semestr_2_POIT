s = 0
i = 1
while i<=20
    s = s+i;
    i=i+1;
end
disp(s);
    