p = 3.14
switch p
    case 3.14
        disp('Chislo Pi');
    otherwise
        disp('Eto ne chislo Pi');
end