s = 0;
for i =1:1:20
    s = s+1;
end
disp(s);