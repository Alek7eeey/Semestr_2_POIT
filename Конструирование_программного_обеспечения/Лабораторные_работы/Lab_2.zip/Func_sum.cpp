#pragma once
#include "stdafx.h"

int sum(int a, int b)
{
	return a + b;
}